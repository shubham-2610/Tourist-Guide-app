package com.example.mini;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class jaipur_place extends AppCompatActivity {
    Button hawa,cab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jaipur_place);

        hawa = findViewById(R.id.pay);
        hawa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), hawa_mahal.class);
                startActivity(intent);
            }
        });
        cab = findViewById(R.id.cab);
        cab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), jaipur_cab.class);
                startActivity(intent);
            }
        });
    }
}