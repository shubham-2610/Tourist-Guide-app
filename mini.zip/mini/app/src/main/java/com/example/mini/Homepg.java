package com.example.mini;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Homepg extends AppCompatActivity {

    private ImageView delhi, karnataka, rajasthan, home, car,place;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepg);
        delhi= (ImageView) findViewById(R.id.img_delhi);
        karnataka =(ImageView) findViewById(R.id.karnataka);
        rajasthan =(ImageView) findViewById(R.id.rajasthan);


        delhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), delhi_tourist.class);
                startActivity(intent);
            }
        });

        karnataka.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), karnataka_tourist.class);
                startActivity(intent);
            }
        });

        rajasthan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Rajasthan_tourist.class);
                startActivity(intent);
            }
        });
        home = (ImageView) findViewById(R.id.home_btn) ;
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Homepg.class);
                startActivity(intent);
            }
        });
        car = findViewById(R.id.car_vec);
        car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openDialog();
            }
        });
        place=findViewById(R.id.place);
        place.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), profile_.class);
                startActivity(intent);
            }
        });


    }
    public void openDialog(){
        exampleDialog exampleDialog= new exampleDialog();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

}

