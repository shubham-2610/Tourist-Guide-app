package com.example.mini;
import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import org.json.JSONObject;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
public class delhi_hotel extends AppCompatActivity {

    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("bookings");


    TextView checkIn , checkOut , showCheckIn , showCheckOut;
    Uri uri;
    Button pay;
    RadioGroup radioGroup;
    RadioButton standard,deluxe,executive;
    TextView price , total;
    EditText nights , guests , name , phNumber , email;

    Button booking;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delhi_hotel);

        FirebaseApp.initializeApp(delhi_hotel.this);
        radioGroup = findViewById(R.id.radioGroup);
        guests = findViewById(R.id.guests);
        standard = findViewById(R.id.standard);
        deluxe = findViewById(R.id.deluxe);
        executive = findViewById(R.id.executive);
        nights =findViewById(R.id.nights);
        total = findViewById(R.id.total);
        price = findViewById(R.id.price);
        checkIn = findViewById(R.id.checkIn);
        checkOut = findViewById(R.id.checkOut);
        showCheckIn = findViewById(R.id.showCheckIn);
        showCheckOut = findViewById(R.id.showCheckOut);
        name = findViewById(R.id.name);
        phNumber = findViewById(R.id.phNumber);
        email = findViewById(R.id.email);
        pay = findViewById(R.id.pay);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                String noOfNightsText = nights.getText().toString();

                if (!noOfNightsText.isEmpty()) {
                    int noOfNights = Integer.parseInt(noOfNightsText);

                    if (checkedId == R.id.standard){
                        price.setText("1000");
                        total.setText(""+noOfNights*1000);
                    } else if (checkedId == R.id.deluxe) {
                        price.setText("1800");
                        total.setText(""+noOfNights*1800);
                    } else if (checkedId == R.id.executive) {
                        price.setText("2400");
                        total.setText(""+noOfNights*2400);
                    }else {
                        price.setText("0");
                        total.setText("0");
                    }
                }
            }
        });
        checkIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });

        checkOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog1();
            }
        });



            Checkout.preload(delhi_hotel.this);

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String guest = guests.getText().toString();
                String prices = price.getText().toString();
                String showCheckIns = showCheckIn.getText().toString();
                String showCheckOuts = showCheckOut.getText().toString();
                String names = name.getText().toString();
                String phNumbers = phNumber.getText().toString();
                String emails = email.getText().toString();
                if (guest.isEmpty() || prices.isEmpty() ||showCheckIns.isEmpty() ||showCheckOuts.isEmpty() ||names.isEmpty() ||phNumbers.isEmpty() ||emails.isEmpty()){
                    Toast.makeText(delhi_hotel.this, "Please enter the details", Toast.LENGTH_SHORT).show();
                }else {
//                    Booking booking = new Booking(guest, prices, showCheckIns, showCheckOuts, names, phNumbers, emails);
//                    reference.push().setValue(booking);
                    startPayment(Integer.parseInt(total.getText().toString()));
                }
            }
        });
    }

    public  void  startPayment(int amount){
        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_0PbVPqIB2RI41v");

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name","Payment");
            jsonObject.put("description","hello");
            jsonObject.put("theme.color", "#3399cc");
            jsonObject.put("currency", "INR");
            jsonObject.put("amount", amount*100);//pass amount in currency subunits
            jsonObject.put("prefill.email", "shubhamohdar26@gmail.com");
            jsonObject.put("prefill.contact","8987646334");
            JSONObject retryObj = new JSONObject();
            retryObj.put("enabled", true);
            retryObj.put("max_count", 4);
            jsonObject.put("retry", retryObj);

            checkout.open(delhi_hotel.this,jsonObject);
        }catch (Exception e){
            Toast.makeText(delhi_hotel.this, "error ", Toast.LENGTH_SHORT).show();
        }
    }


    public void onPaymentSuccess(String s) {
        String guest = guests.getText().toString();
        String prices = price.getText().toString();
        String showCheckIns = showCheckIn.getText().toString();
        String showCheckOuts = showCheckOut.getText().toString();
        String names = name.getText().toString();
        String phNumbers = phNumber.getText().toString();
        String emails = email.getText().toString();
        d_hotel d_hotel = new d_hotel(guest, prices, showCheckIns, showCheckOuts, names, phNumbers, emails);
       // String hotel_name,String guest, String prices, String showCheckIns, String showCheckOuts, String names, String phNumbers, String emails, String totals, String duration
        reference.push().setValue(d_hotel);
        Toast.makeText(delhi_hotel.this, "success", Toast.LENGTH_SHORT).show();
    }


    public void onPaymentError(int i, String s) {
        Toast.makeText(delhi_hotel.this, "failed", Toast.LENGTH_SHORT).show();
    }


    private void openDialog() {
        Calendar calendar = Calendar.getInstance();
        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH);
        int currentDay = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                // Adjust the month value by adding 1
                int newMonth = month + 1;
                // Format the date components with leading zeros if needed
                String formattedMonth = String.format(Locale.US, "%02d", newMonth);
                String formattedDayOfMonth = String.format(Locale.US, "%02d", dayOfMonth);
                // Concatenate the date components in the desired order
                String selectedDate = formattedDayOfMonth + "/" + formattedMonth + "/" + year;
                showCheckIn.setText(selectedDate);
                showCheckOut.setText("");
            }
        }, currentYear, currentMonth, currentDay);

        dialog.getDatePicker().setMinDate(calendar.getTimeInMillis());

        dialog.show();
    }

    private void openDialog1() {
        // Get the selected check-in date
        String checkInDate = showCheckIn.getText().toString();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
        Date selectedCheckInDate;
        try {
            selectedCheckInDate = dateFormat.parse(checkInDate);
        } catch (ParseException e) {
            // Handle parsing exception if needed
            return;
        }

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(selectedCheckInDate);

        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH);
        int currentDay = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                // Adjust the month value by adding 1
                int adjustedMonth = month + 1;
                // Format the date components with leading zeros if needed
                String formattedMonth = String.format(Locale.US, "%02d", adjustedMonth);
                String formattedDayOfMonth = String.format(Locale.US, "%02d", dayOfMonth);
                // Concatenate the date components in the desired order
                String selectedDate = formattedDayOfMonth + "/" + formattedMonth + "/" + year;
                showCheckOut.setText(selectedDate);
            }
        }, currentYear, currentMonth, currentDay);

        dialog.getDatePicker().setMinDate(calendar.getTimeInMillis());

        dialog.show();
    }


}


