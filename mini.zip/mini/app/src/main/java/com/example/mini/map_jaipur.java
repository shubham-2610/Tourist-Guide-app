package com.example.mini;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.FrameLayout;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class map_jaipur extends AppCompatActivity {

    GoogleMap gmap;
    FrameLayout map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_jaipur);

        map = findViewById(R.id.maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.maps);
        mapFragment.getMapAsync(this::onMapReady);

    }

    private void onMapReady(GoogleMap googleMap) {

        this.gmap = googleMap;

        LatLng mapIndia = new LatLng(26.9239, 75.8267);// these two coordinate u change as per ur location, in google ull get the coordinate. search like coordinate for mangalore
        this.gmap.addMarker(new MarkerOptions().position(mapIndia).title("Marker in Hawa Mahal"));//here put place name
        this.gmap.moveCamera(CameraUpdateFactory.newLatLng(mapIndia));
    }
}