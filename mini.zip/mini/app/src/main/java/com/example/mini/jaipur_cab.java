package com.example.mini;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class jaipur_cab extends AppCompatActivity {

    Button cab_book;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jaipur_cab);


        cab_book = findViewById(R.id.cab_book1);
        cab_book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openDialog();
            }
        });


    }
    public void openDialog(){
        exampleDialog exampleDialog= new exampleDialog();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }
}