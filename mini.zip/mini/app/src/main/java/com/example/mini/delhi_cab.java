package com.example.mini;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class delhi_cab extends AppCompatActivity {

    Button hotel, cab_book;
    private ImageView home,cab,place;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delhi_cab);

        hotel = findViewById(R.id.delhi_hotel);
        hotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), delhi_tourist.class);
                startActivity(intent);
            }
        });
        home = (ImageView) findViewById(R.id.home) ;
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Homepg.class);
                startActivity(intent);
            }
        });

        cab_book = findViewById(R.id.cab_book8);
        cab_book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                openDialog();
            }
        });


    }
    public void openDialog(){
        exampleDialog exampleDialog= new exampleDialog();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }




}
