package com.example.mini;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class delhi_tourist extends AppCompatActivity {

    Button hotel, book, cab, visit,book_btn;
    private ImageView home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delhi_tourist);

        hotel = findViewById(R.id.delhi_hotel);
        hotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), delhi_tourist.class);
                startActivity(intent);
            }
        });
        book = findViewById(R.id.hotel_btn);
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), delhi_hotel.class);
                startActivity(intent);
            }
        });

        cab = findViewById(R.id.cab);
        cab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), delhi_cab.class);
                startActivity(intent);
            }
        });
        home = (ImageView) findViewById(R.id.home) ;
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Homepg.class);
                startActivity(intent);
            }
        });
        visit = findViewById(R.id.visit) ;
        visit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), delhi_place.class);
                startActivity(intent);
            }
        });
        book_btn = findViewById(R.id.rad_btn);
        book_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), delhi_hotel.class);
                startActivity(intent);
            }
        });

    }
    }
