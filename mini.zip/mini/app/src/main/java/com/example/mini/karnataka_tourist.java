package com.example.mini;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class karnataka_tourist extends AppCompatActivity {
    private ImageView home;
    Button mysore, blr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.karnataka_tourist);

        home = (ImageView) findViewById(R.id.home) ;
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Homepg.class);
                startActivity(intent);
            }
        });
        mysore = findViewById(R.id.mysore);
        mysore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), com.example.mini.mysore.class);
                startActivity(intent);
            }
        });
        blr = findViewById(R.id.blr);
        blr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Bangalore_tourist.class);
                startActivity(intent);
            }
        });
    }
}